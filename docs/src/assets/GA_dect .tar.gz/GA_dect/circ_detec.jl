#load basic packages
using PyPlot, Liga
layout(2)


function findind(tensor::Array{Float64,3})
  	(m,n,p)=size(tensor)
  	vlmax=maximum(tensor)
  	for i=1:m,j=1:n,k=1:p
              if tensor[i,j,k]==vlmax
                  return i,j,k,vlmax
              end
	end
end


function main(filename)
	#reading the example file
	A=readdlm(filename)
	#setting the size of the image and defining main parameters
	m=300
    n=300
	maxrad=150	
	npun=length(A[:,1])	
	Vot=zeros(m,n,maxrad)
	#embeding A in conformal space and stored in EA
    EA=Array{cmultvec,2}(npun,1)
    einf=cb(id, true, false, 1.0)
	ea12=cb(e12, false, false, 1.0)
    eaid=cb(id, true, false, -1.0)
    SS=cmultvec(1.0*(e1,false,true))
	raio=1.0
	centro=[1.0,1.0]
	for i=1:npun
		EA[i]=conformal([A[i,1],A[i,2]])
	end
    #display(EA)
	#the main block of the idea
    #for i=1:npun,j=i+1:npun,k=j+1:npun #conservative method
	for i=1:2:npun,j=i+1:3:npun,k=j+1:5:npun #speed up				
		X=EA[i]^EA[j]^EA[k]
		SS=dual(X)
		raio = sqrt(((SS⋅SS)/((SS⋅einf)⋅(SS⋅einf))).comp[1].scl) 
		centro = conftore(projection(SS, ea12) / (SS ⋅ eaid))
        if 1.0<=centro[1]<=m && 1.0<=centro[2]<=n
			if 1.0<=abs(raio)<=maxrad
				centro=round.(Int,centro)
				raio=abs.(round(Int,raio))
				Vot[centro[1],centro[2],raio]=Vot[centro[1],centro[2],raio]+1
			end
		end		
	end	
	
	sol=zeros(3)
	valsol=0.0
	sol[1],sol[2],sol[3],valsol=findind(Vot)
	
	display(sol)
	display(valsol)

	draw_solution(A,sol[1],sol[2],sol[3])

end

function draw_solution(A,cfx,cfy,rf)
	angulo=[0:((2*pi)/360):2*pi+1;]
	x=zeros(length(angulo))
	y=zeros(length(angulo))
	for i=1:length(angulo)
    	x[i]=(abs(rf)*cos(angulo[i])+cfx)
   		y[i]=(abs(rf)*sin(angulo[i])+cfy)
	end
	plot(A[:,1],A[:,2],".")
	plot(x,y,color="red","-")
	ax=gca()
	ax[:axis]("equal")
end

